import { Injectable } from '@angular/core';
import { HttpClient  } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { AppSettings } from './appsettings';

//assets/config/
const SETTINGS_LOCATION = 'assets/appsettings.json';
@Injectable({
    providedIn: 'root'
  })

export class AppSettingsService {
      config: AppSettings;

    constructor(private http: HttpClient) {
    }
    /*
    async apiUrl(): Promise<AppSettings> {
        let conf = await this.getConfig();
        console.log(conf);
        return Promise.resolve(conf);
    }

    private async getConfig(): Promise<AppSettings> {
        if (!this.config) {
            this.config = (await this.http.get('/assets/config.json').toPromise());
        }
        return Promise.resolve(this.config);
    }
    */
    loadConfig() {
     return this.http
       .get<AppSettings>('./assets/appsettings.json')
       .toPromise()
       .then(config => {
         this.config = config;
         console.log(this.config);
       });
   }

}

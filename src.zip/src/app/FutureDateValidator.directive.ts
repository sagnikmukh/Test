import { Directive } from '@angular/core';
import { Validator, NG_VALIDATORS, ValidatorFn, FormControl } from '@angular/forms';

@Directive({
  selector: '[appFutureDateValidator]',
  providers: [
    {
      provide: NG_VALIDATORS,
      useClass: FutureDateValidator,
      multi: true
    }
  ]
})
export class FutureDateValidator implements Validator {

  validator: ValidatorFn;
  constructor() {
    this.validator = this.futureDateValidator();
  }

  validate(c: FormControl) {
    return this.validator(c);
  }

  futureDateValidator(): ValidatorFn {
    return (control: FormControl) => {
      if (control.value != null && control.value !== '') {
        const isValid = /^(0[1-9]|1[0-2])\/(0[1-9]|1\d|2\d|3[01])\/(19|20)\d{2}$/.test(control.value);
        //console.log('test');
        if (isValid) {
            const c = new Date();
            if (new Date(control.value) > c )
            {
                return {
                    futureDateValidator: { valid: false }
                  };
            }
            return null;
        } else {
          return null;
        }
      } else {
        return null;
      }
    };
  }
}

import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AppSettingsService } from './appsettings.service';
import { APP_INITIALIZER } from '@angular/core';
import { PreloadFactory } from './preload-service.factory';
import { HomeComponent } from './home/home.component';
import { FormsModule } from '@angular/forms';
import { FutureDateValidator } from './FutureDateValidator.directive';
import { DateRangeValidator } from './DateRangeValidator.directive';
import { RequiredfieldValidation } from './requiredfields.directive';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    FutureDateValidator,
    DateRangeValidator,
    RequiredfieldValidation,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    HttpClientModule,
    RouterModule.forRoot([
      { path: '', component: HomeComponent }
    ])
  ],
  providers: [AppSettingsService,
    {
      provide: APP_INITIALIZER,
      deps: [
        AppSettingsService
      ],
      multi: true,
      useFactory: PreloadFactory
    }],
  bootstrap: [AppComponent]
})
export class AppModule { }

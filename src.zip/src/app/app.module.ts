
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AppSettingsService } from './appsettings.service';
import { APP_INITIALIZER } from '@angular/core';
import { PreloadFactory } from './preload-service.factory';
import { HomeComponent } from './home/home.component';
import { FormsModule } from '@angular/forms';
import { FutureDateValidator } from './FutureDateValidator.directive';
import { DateRangeValidator } from './DateRangeValidator.directive';
import { RequiredfieldValidation } from './requiredfields.directive';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { TestComponent } from './test/test.component';


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    FutureDateValidator,
    DateRangeValidator,
    RequiredfieldValidation,
    TestComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    HttpClientModule,
    RouterModule.forRoot([
      { path: '', component: HomeComponent },
      { path: 'test', component: TestComponent }
    ]),
    NgbModule
  ],  
  providers: [AppSettingsService,
    {
      provide: APP_INITIALIZER,
      deps: [
        AppSettingsService
      ],
      multi: true,
      useFactory: PreloadFactory
    }],
  bootstrap: [AppComponent]
})
export class AppModule { }

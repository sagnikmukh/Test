import { WireSearch } from './../model/WireSearch';
import {Component, Injectable} from '@angular/core';
import {NgbCalendar, NgbDateAdapter, NgbDateParserFormatter, NgbDateStruct} from '@ng-bootstrap/ng-bootstrap';
import { CustomAdapter, CustomDateParserFormatter } from '../datepicker-adapter';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css'],
  providers: [
    {provide: NgbDateAdapter, useClass: CustomAdapter},
    {provide: NgbDateParserFormatter, useClass: CustomDateParserFormatter}
  ]
})
export class TestComponent {

  wireSearch: WireSearch = {WireId: null, ProcessDate: null, category: null, InputDate: null};
  calculatedMinDate: Date;
  currentDate: Date;
  maxDate: NgbDateStruct;
  minDate: NgbDateStruct;
  startDate: NgbDateStruct;
  dateValidationStatus: boolean;
  dateValidationMessage: string;

   constructor(private ngbCalendar: NgbCalendar, private dateAdapter: NgbDateAdapter<string>) {

    this.dateValidationStatus = false;
    this.dateValidationMessage = '';

    this.currentDate = new Date();
    this.maxDate = {year: this.currentDate.getFullYear(), month: this.currentDate.getMonth() + 1, day: this.currentDate.getDate()};
    this.wireSearch.InputDate = this.formatDate(this.currentDate);
    this.calculatedMinDate = new Date();
    this.calculatedMinDate.setDate(this.currentDate.getDate() - 7);
    // tslint:disable-next-line: max-line-length
    this. minDate = {year: this.calculatedMinDate.getFullYear(), month: this.calculatedMinDate.getMonth()+1, day: this.calculatedMinDate.getDate()};
   }

  save(input: WireSearch) {
    console.log(input);
  }
  onDateSelected()
  {
    console.log('onDateSelected');
    this.DateValidation(this.wireSearch.InputDate);
  }

  onTxtChange()
  {
    console.log('onTxtChange');
    this.DateValidation(this.wireSearch.InputDate);
  }

  DateValidation(input: string): boolean
  {
    this.dateValidationStatus = false;
    this.dateValidationMessage = '';

    if ( input !== '' || input != null)
    {
      console.log(input);
      if (this.ValidDate(input))
      {
        const date = input.split('/');
        const dateObject = new Date( parseInt(date[0], 10) + '/' + parseInt(date[1], 10) + '/' + parseInt(date[2], 10));
        console.log(dateObject);
        if (!this.futureDateValidation(dateObject))
        {
          if (this.ValidateDateRange(dateObject, 7))
          {
            this.dateValidationStatus = true;
            this.dateValidationMessage = 'Date is prior to 7 days';
          }
        }
        else
        {
          this.dateValidationStatus = true;
          this.dateValidationMessage = 'Future Date is not allowed';
        }
      }
      else
      {
        this.dateValidationStatus = true;
        this.dateValidationMessage = 'Invalid Date';
      }
    }
    return true;
  }

  ValidDate(input: string): boolean
  {
    const isValid = /^(0[1-9]|1[0-2])\/(0[1-9]|1\d|2\d|3[01])\/(19|20)\d{2}$/.test(input);
    return isValid;
  }

  // tslint:disable-next-line: member-ordering
  futureDateValidation( input: Date): boolean
  {
    if (input)
    {
      const currentDate = new Date();
      currentDate.setHours(0, 0, 0, 0);
      if (new Date(input) > currentDate)
          {
            return true;
          }
      return false;
    }
  }

  ValidateDateRange(input: Date, numberOfDays: number): boolean
  {
    const currentDate = new Date();
    currentDate.setHours(0, 0, 0, 0);
    currentDate.setDate(currentDate.getDate() - numberOfDays);
    if (new Date(input) < currentDate )
    {
      return true;
    }
    return false;
  }

  formatDate(date: Date): string
  {
    const d = new Date(date);
    let month = '' + (d.getMonth() + 1);
    let day = '' + d.getDate();
    const year = d.getFullYear();
    if ( month.length < 2) {
        month = '0' + month;
    }
    if (day.length < 2) {
        day = '0' + day;
    }
    return [month, day, year].join('/');
  }
}

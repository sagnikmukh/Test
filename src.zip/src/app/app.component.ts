import { Component, OnInit } from '@angular/core';
import { AppSettings } from './appsettings';
import { AppSettingsService } from './appsettings.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  constructor(private appSettingsService: AppSettingsService) {
  }
  
  public title = '';
  ngOnInit() {
    console.log(this.appSettingsService.config.defaultUrl);
  }
}

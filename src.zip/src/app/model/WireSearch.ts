export interface WireSearch{
    WireId: number;
    ProcessDate: Date;
    category:number;
}
import { Directive, Input } from '@angular/core';
import { NG_VALIDATORS, Validator, ValidationErrors, FormGroup } from '@angular/forms';

@Directive({
    selector: '[appRequiredfields]',
    providers: [{ provide: NG_VALIDATORS, useExisting: RequiredfieldValidation, multi: true }]
})
export class RequiredfieldValidation implements Validator {
    @Input('appRequiredfields') mustMatch: string[] = [];

    validate(formGroup: FormGroup): ValidationErrors {
        return Requiredfields(this.mustMatch[0], this.mustMatch[1])(formGroup);
    }
}
// custom validator to check that two fields match
export function Requiredfields(controlName: string, matchingControlName: string) {
    return (formGroup: FormGroup) => {
        const control = formGroup.controls[controlName];
        const matchingControl = formGroup.controls[matchingControlName];

        // return null if controls haven't initialised yet
        if (!control || !matchingControl) {
          return null;
        }

        // return null if another validator has already found an error on the matchingControl
        if (matchingControl.errors && !matchingControl.errors) {
            return null;
        }

        // set error on matchingControl if validation fails
        if (control.value === '' && matchingControl.value === '') {
            matchingControl.setErrors({ requiredfieldsMatch: false });
        } else {
            matchingControl.setErrors(null);
        }
    }
}

import { Directive, Input } from '@angular/core';
import { Validator, NG_VALIDATORS, ValidatorFn, FormControl } from '@angular/forms';

@Directive({
  selector: '[appDateRangeValidator]',
  providers: [
    {
      provide: NG_VALIDATORS,
      useExisting: DateRangeValidator,
      multi: true
    }
  ]
})
export class DateRangeValidator implements Validator {
  @Input() appDateRangeValidator: string;
  validator: ValidatorFn;

  constructor() {}

  ngOnInit() {
    this.validator = this.dateRangeValidator(this.appDateRangeValidator);
  }

  validate(c: FormControl) {
    return this.validator(c);
  }

  dateRangeValidator(days: string): ValidatorFn {
    return (control: FormControl) => {
      if (control.value != null && control.value !== '') {
        const isValid = /^(0[1-9]|1[0-2])\/(0[1-9]|1\d|2\d|3[01])\/(19|20)\d{2}$/.test(control.value);
        console.log(this.appDateRangeValidator);
        if (isValid) {
            const c = new Date();
            c.setDate(c.getDate() - Number(this.appDateRangeValidator));
            console.log(c);
            if (new Date(control.value) < c )
            {
              console.log('7 days old');
                return {
                    dateRangeValidator: { valid: false }
                  };
            }
            return null;
        } else {
          return null;
        }
        return null;
      } else {
        return null;
      }
    };
  }
}

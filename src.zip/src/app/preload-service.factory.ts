import { AppSettingsService } from './appsettings.service';

export function PreloadFactory(configService: AppSettingsService) {
  return () => configService.loadConfig();
}

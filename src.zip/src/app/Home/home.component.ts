import { WireSearch } from './../model/WireSearch';
import {Component, Injectable} from '@angular/core';
import {NgbCalendar, NgbDateAdapter, NgbDateParserFormatter, NgbDateStruct} from '@ng-bootstrap/ng-bootstrap';



/**
 * This Service handles how the date is represented in scripts i.e. ngModel.
 */
@Injectable()
export class CustomAdapter extends NgbDateAdapter<string> {

  readonly DELIMITER = '/';

  fromModel(value: string | null): NgbDateStruct | null {
    if (value) {
      let date = value.split(this.DELIMITER);
      return {
        day : parseInt(date[1], 10),
        month : parseInt(date[0], 10),
        year : parseInt(date[2], 10)
      };
    }
    return null;
  }

  toModel(date: NgbDateStruct | null): string | null {    
    return date ? date.month + this.DELIMITER + date.day + this.DELIMITER + date.year : null;
  }
}

/**
 * This Service handles how the date is rendered and parsed from keyboard i.e. in the bound input field.
 */
@Injectable()
export class CustomDateParserFormatter extends NgbDateParserFormatter {

  readonly DELIMITER = '/';

  parse(value: string): NgbDateStruct | null {
    if (value) {      
      let date = value.split(this.DELIMITER);      
      return {
        day : parseInt(date[1], 10),
        month : parseInt(date[0], 10),
        year : parseInt(date[2], 10)
      };
    }
    return null;
  }

  format(date: NgbDateStruct | null): string {        
    return date ? date.month + this.DELIMITER + date.day + this.DELIMITER + date.year : '';
  }
}

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  providers: [
    {provide: NgbDateAdapter, useClass: CustomAdapter},
    {provide: NgbDateParserFormatter, useClass: CustomDateParserFormatter}
  ]
})
export class HomeComponent {

  model: NgbDateStruct;
  wireSearch: WireSearch = {WireId: null, ProcessDate: null, category:null,InputDate:null};
  runtimes;
  maxdate:Date= new Date();
  formvalidationStatus:boolean=false;
  

  save(input: WireSearch) {    
    console.log(input);
  }

  model2:string;
  maxDate:any={year: 2020, month: 11, day: 24};
  //model2: Date=this.dateAdapter.toModel(this.ngbCalendar.getToday());


  constructor(private ngbCalendar: NgbCalendar, private dateAdapter: NgbDateAdapter<string>) {}

  get today() {
    return this.dateAdapter.toModel(this.ngbCalendar.getToday())!;
  }
  
  onDateSelected()
  {
    console.log('1');
  }

  onTxtChange()
  {
    console.log(2);    
  }

  onChange()
  {
    console.log(this.wireSearch.ProcessDate);
    if (this.wireSearch.ProcessDate)
    {
    const c = new Date();
    c.setHours(0, 0, 0, 0);
    const inputDate = new Date(this.wireSearch.ProcessDate);
    const same = c.getTime() === inputDate.getTime();
    if (same)
    {
      const hour: number = new Date().getHours();
      console.log(hour);
      this.runtimes = this.getRunTimes().filter(city => Number(city.id) < hour);
    }
    else
    {
      console.log('old');
      this.runtimes = this.getRunTimes();
    }
  }
  else
  {
    this.runtimes=null;
    console.log('null');
  }
  }

  getRunTimes() {
    return [
      { id: '0', name: 'All' },
      { id: '9', name: '9am' },
      { id: '110', name: '10am' },
      { id: '11', name: '11am' },
      { id: '120', name: '12pm' },
      { id: '13', name: '1pm' },
      { id: '140', name: '2pm' }
    ];
  }
}

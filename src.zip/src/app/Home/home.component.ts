import { WireSearch } from './../model/WireSearch';
import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {


  wireSearch: WireSearch = {WireId: null, ProcessDate: null, category:null};
  runtimes;
  formvalidationStatus:boolean=false;
  constructor() {
  }

  save(input: WireSearch) {    
    console.log(input);
  }

  ngOnInit(): void {
  }
  onChange()
  {
    console.log(this.wireSearch.ProcessDate);
    if (this.wireSearch.ProcessDate)
    {
    const c = new Date();
    c.setHours(0, 0, 0, 0);
    const inputDate = new Date(this.wireSearch.ProcessDate);
    const same = c.getTime() === inputDate.getTime();
    if (same)
    {
      const hour: number = new Date().getHours();
      console.log(hour);
      this.runtimes = this.getRunTimes().filter(city => Number(city.id) < hour);
    }
    else
    {
      console.log('old');
      this.runtimes = this.getRunTimes();
    }
  }
  else
  {
    this.runtimes=null;
    console.log('null');
  }
  }

  getRunTimes() {
    return [
      { id: '0', name: 'All' },
      { id: '9', name: '9am' },
      { id: '110', name: '10am' },
      { id: '11', name: '11am' },
      { id: '120', name: '12pm' },
      { id: '13', name: '1pm' },
      { id: '140', name: '2pm' }
    ];
  }
}

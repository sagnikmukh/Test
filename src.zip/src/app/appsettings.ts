export class AppSettings {
    defaultUrl: string;
    defaultPrice: string;
  }
